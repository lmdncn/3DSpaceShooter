﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

/// <summary>
/// Displays the Shoot Game user Gameplay log
/// </summary>
public class shootHistory : MonoBehaviour {

    public Text history;

    // Use this for initialization
    /// <summary>
    /// Set the serialized data of the shoot Gameplay log to the history text
    /// </summary>
    void Start () {

    }

}
