﻿using UnityEngine;
using System.Collections;

public class BkMusic : MonoBehaviour {

    

	// Use this for initialization
	void Awake () {
        DontDestroyOnLoad(this);

	}

    public void stopBKMusic() {
        Destroy(this.gameObject, 1f);
    }

    void Start() { }

	// Update is called once per frame
	void Update () {
	
	}

}
